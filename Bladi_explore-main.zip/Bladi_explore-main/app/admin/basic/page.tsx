export default function BasicAdminPage() {
  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">Administration Basique</h2>
      <p>Page d'administration avec un layout minimal.</p>
    </div>
  )
}
