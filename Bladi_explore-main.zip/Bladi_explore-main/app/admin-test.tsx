export default function AdminTestPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold">Page de test d'administration</h1>
      <p>Si vous voyez cette page, le routing fonctionne correctement.</p>
    </div>
  )
}
