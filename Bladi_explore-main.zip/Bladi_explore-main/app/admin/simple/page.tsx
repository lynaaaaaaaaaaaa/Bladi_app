export default function SimpleAdminPage() {
  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">Page d'administration simplifiée</h2>
      <p>Cette page utilise un layout simplifié pour tester l'accès à l'administration.</p>
    </div>
  )
}
